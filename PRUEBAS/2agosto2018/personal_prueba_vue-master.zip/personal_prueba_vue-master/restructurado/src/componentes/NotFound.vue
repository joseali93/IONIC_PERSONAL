<template>
  <div>
      <h3>no encontrado</h3>
      <router-link to="/inicio">Regresar al inicios</router-link>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
