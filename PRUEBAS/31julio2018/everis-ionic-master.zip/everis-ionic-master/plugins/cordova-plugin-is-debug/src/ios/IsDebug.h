#import <Cordova/CDV.h>

@interface IsDebug : CDVPlugin {
  // Member variables go here.
}

- (void)getIsDebug:(CDVInvokedUrlCommand*)command;
@end