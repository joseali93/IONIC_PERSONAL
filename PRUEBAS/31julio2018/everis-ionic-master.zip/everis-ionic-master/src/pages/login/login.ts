import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { AlertProvider } from './../../providers/alert';
import { LoadingProvider } from './../../providers/loading';
import { RequestProvider } from './../../providers/request';
import { HomePage } from './../home/home';

@Component({
  selector: 'page-login',
  templateUrl: 'login.html'
})
export class LoginPage {

  public username: string;
  public password: string;

  constructor(public navCtrl: NavController,
    public request: RequestProvider,
    public loading: LoadingProvider,
    public alert: AlertProvider) {

  }

  public login(): void {
    this.loading.show();

    let url: string = 'https://httpbin.org/anything';
    url += '/' + this.username;
    url += '/' + this.password;

    console.log('Username: ' + this.username);
    console.log('Password: ' + this.password);
    console.log('URL: ' + url);

    this.request.get(url).then(result => {
      console.log('Success', result);
      this.loading.dismiss();

      this.navCtrl.setRoot(HomePage);
    }).catch(error => {
      console.log('Error', error);
      this.loading.dismiss();
      this.alert.show('Error de autenticación');
    });
  }
}